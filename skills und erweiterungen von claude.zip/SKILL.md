---
name: kontenlage-wphg-guardrails
description: Cross-cutting Compliance-Regelwerk für ALLE nutzerseitigen Kontenlage-Ausgaben (Artikel, Score-Labels, Archetyp-Beschreibungen, Alert-Texte, Profil-Tool-Ergebnisse). MUSS konsultiert werden, bevor irgendein Text generiert oder veröffentlicht wird, der eine Anlagekategorie nennt, sich auf Nutzereingaben bezieht, oder als Ergebnis eines personalisierten Tools angezeigt wird. Trigger IMMER bei: Artikeltext mit Anlageklassen-Bezug, Score-Beschreibungen, Profil-/Archetyp-Ausgaben, Alert-Nachrichten, jede Formulierung die "du/dir/dein" in Bezug auf eine Anlageempfehlung verwenden könnte. Andere Kontenlage-Skills (scoring-engine, content-drafter, fact-alert-composer, archetype-quiz-maintainer) MÜSSEN dieses Regelwerk vor jedem Publish-Schritt anwenden.
---

# Kontenlage WpHG-Guardrails

Ziel: Kontenlage bleibt Finanzbildung (§ 2 Abs. 8 Nr. 10 WpHG-Ausnahme: öffentliche Informationsverbreitung ohne persönliche, auf Einzelfall gestützte Empfehlung) und wird nicht zur erlaubnispflichtigen Anlageberatung oder Anlagevermittlung.

## Rechtlicher Kern (für Kontext, nicht wörtlich zitieren)

Anlageberatung liegt vor, wenn eine Empfehlung (a) sich auf **bestimmte** Finanzinstrumente bezieht UND (b) entweder auf einer Prüfung persönlicher Umstände beruht ODER als für den Anleger geeignet **dargestellt** wird UND (c) nicht ausschließlich über öffentliche Informationskanäle verbreitet wird. Alle drei Elemente müssen zusammenkommen — Kontenlage hält das System so, dass mindestens eines strukturell fehlt.

## Regel 1 — Kategorie-Ebene, nie konkretes Produkt

**Erlaubt:** Anlageklassen-Begriffe (Tagesgeld, Geldmarktfonds, Welt-ETF, Anleihen, Gold, Crypto, DeFi-Lending, Immobilien-AfA-Modelle).

**Verboten:** ISIN, WKN, konkreter Fondsname, konkreter Anbieter/Broker/Emittent, konkretes Krypto-Protokoll mit Eigennamen als "Kaufempfehlung"-Kontext.

Ausnahme: Ein Anbieter/Protokoll darf **rein deskriptiv in einem Artikel erwähnt** werden (z. B. "Aave ist ein Beispiel für ein DeFi-Lending-Protokoll"), niemals aber im Score-System oder in einer personalisierten Ausgabe als Ergebnis erscheinen.

## Regel 2 — Sprache: beschreibend, nie zuschreibend

Vor jeder Textausgabe gegen diese Liste prüfen. Bei Treffer links → durch rechts ersetzen oder Formulierung komplett neu bauen.

| Verboten (zuschreibend/imperativ) | Erlaubt (beschreibend/statistisch) |
|---|---|
| "Für dich passt X" | "Der Typ '[Archetyp]' beschäftigt sich häufig mit X" |
| "Wir empfehlen dir X" | "Nutzer mit diesem Profil lesen häufig über X" |
| "Das ist für dich geeignet" | "Dies ist ein Bildungsangebot, keine individuelle Eignungsprüfung" |
| "Dein optimales Portfolio" | "Ein Beispielportfolio für den Typ X" |
| "Du solltest X kaufen/umschichten" | (nirgends erlaubt — auch nicht umformuliert) |
| "Beste Wahl für dich" | "Eine von mehreren Kategorien" |
| "Basierend auf deinen Angaben empfehlen wir…" | "Basierend auf ähnlichen Angaben interessieren sich Nutzer häufig für…" |

Zusätzliche Wortsperre (nie verwenden, unabhängig vom Kontext): "empfehlen" (in Bezug auf eine konkrete Person), "solltest", "geeignet für dich", "dein optimales", "jetzt handeln", "kaufen/verkaufen" in Imperativform.

## Regel 3 — Struktur des Profil-/Archetyp-Tools

- Feste, kleine Anzahl (4–6) vorab redaktionell erstellter Anlegertypen, identisch für alle Nutzer, selten geändert (siehe archetype-quiz-maintainer-Skill).
- Zuordnung von Quiz-Antworten zu Archetyp erfolgt über **einfache, transparente Regel-Logik** (Punktesystem, keine offene KI-Inferenz für den user-facing Output).
- Ergebnis-Ansicht zeigt IMMER den zugeordneten Typ NEBEN der vollständigen Übersicht aller Typen — nie als isolierten "Dein Ergebnis"-Screen.
- Keine Rückspiegelung eingegebener Zahlen im Ergebnistext (kein "Bei deinen 87.000 €…").
- Disclaimer direkt am Ergebnis, nicht nur im Footer.

## Regel 4 — Keine Anlagevermittlung durch die Hintertür

- Kein Direktlink zu einem Kauf-/Abschlussprozess bei einem konkreten Anbieter.
- Keine Provision/Zuwendung von Produktanbietern, auch nicht indirekt (Affiliate-Links sind für dieses Projekt tabu, unabhängig vom Tier).
- Executive-Tier darf mehr Detailtiefe/Häufigkeit bieten, niemals aber konkretere Produktnennung.

## Eskalationsregel

Nur **Methodik-Änderungen** (neue Bewertungsdimension, geänderte Bandgrenzen, geänderte Quellen-Gewichtung, neuer Archetyp) gehen an Igor zur Freigabe. Inhaltliche Unsicherheit bei einzelnen Datenpunkten wird automatisch unterdrückt (siehe scoring-engine-Skill), nicht eskaliert — das ist keine Governance-Frage, sondern eine Datenqualitätsfrage, die das System selbst lösen soll.

## Selbstprüf-Checkliste vor jedem Publish

1. Wird ein konkretes Produkt/ISIN/Anbieter genannt? → Falls ja: STOP, auf Kategorie-Ebene umschreiben.
2. Enthält der Text ein Wort aus der Wortsperre? → Falls ja: STOP, umformulieren.
3. Bezieht sich der Text auf individuelle Nutzereingaben mit zuschreibender Sprache? → Falls ja: STOP, in beschreibende Form bringen.
4. Fehlt der Disclaimer am Ausgabepunkt? → Falls ja: ergänzen.
5. Alle vier Punkte sauber? → Publish gemäß Grün/Gelb/Rot-Status aus scoring-engine-Skill.
