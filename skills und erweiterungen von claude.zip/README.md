# Kontenlage — Hermes-Skill-Map

## Fertig ausgearbeitet (in diesem Paket)

| Skill | Zweck |
|---|---|
| `wphg-guardrails` | Cross-cutting Compliance-Regelwerk — Kategorie-Ebene, Sprachregeln, Archetyp-Struktur, Selbstprüf-Checkliste. Wird von allen anderen Skills konsultiert. |
| `scoring-engine` | Berechnet Risk/Opportunity/Evidence-Bänder, wendet Grün/Gelb/Rot-Publish-Gate an, verhindert Fake-Präzision. |
| `fact-alert-composer` | Formuliert Telegram/Messenger-Alerts aus freigegebenen Datenänderungen — strikt faktisch, nie Signal. |

## Geplant (nächste Kategorie, analog deinem Batch-Ansatz)

**`source-evaluator`**
Findet und bewertet Quellen (Tier 1–3 nach Gewichtungstabelle aus scoring-engine), extrahiert Fakten mit Zitat, erkennt Widersprüche zwischen Quellen und übergibt strukturierte Daten an scoring-engine. Das ist die Research-Schicht vor dem Scoring.

**`content-drafter`**
Verwandelt Score- und Research-Output in publizierbaren Artikel-/Vergleichstext im etablierten Kontenlage-Ton (neutral, mathematisch, "Stand: Datum", Quellen inline). Wendet wphg-guardrails-Sprachregeln automatisch an, bevor Text in die Grün/Gelb/Rot-Pipeline geht.

**`archetype-quiz-maintainer`**
Pflegt die kleine, feste Anzahl (4–6) redaktioneller Anlegertyp-Beschreibungen für das Profil-Tool sowie die einfache, transparente Punkte-Logik, die Quiz-Antworten einem Typ zuordnet. Bewusst regelbasiert statt offener KI-Inferenz für den nutzerseitigen Output — das ist der Kern der strukturellen WpHG-Absicherung des Profil-Tools.

## Reihenfolge-Empfehlung

1. `source-evaluator` als Nächstes — ohne saubere, gewichtete Quellenlage kann scoring-engine nicht sinnvoll laufen.
2. `content-drafter` danach — verbindet Score-Output mit der bestehenden Artikel-Struktur der Seite.
3. `archetype-quiz-maintainer` erst nach dem einmaligen Rechtscheck zum Profil-Tool-Design (siehe Update v2, Abschnitt 4).
