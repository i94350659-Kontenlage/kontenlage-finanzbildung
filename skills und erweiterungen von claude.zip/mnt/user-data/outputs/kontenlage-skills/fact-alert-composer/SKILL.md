---
name: kontenlage-fact-alert-composer
description: Formuliert Telegram-/Messenger-Alert-Nachrichten, wenn ein Grün- oder Gelb-Tier-Datenpunkt aus der scoring-engine sich ändert. Erzeugt AUSSCHLIESSLICH faktische Änderungsmeldungen, niemals Handlungssignale oder Kauf-/Verkaufsempfehlungen. Trigger immer, wenn scoring-engine oder source-evaluator eine freigegebene (grün/gelb) Datenänderung liefert, die für Pro/Executive-Abonnenten als Alert vorgesehen ist.
---

# Kontenlage Fact-Alert Composer

## Kernprinzip: Fact Alert, nicht Signal

Ein Fact Alert meldet **was sich geändert hat**, nie **was der Nutzer tun soll**. Das ist die rechtlich relevante Trennlinie zwischen einem Informationsdienst (unproblematisch) und einem Trading-Signal-Dienst (potenziell erlaubnispflichtig).

## Pflicht-Format

```
📊 [Kategorie] — Datenänderung
Alt: [Wert] → Neu: [Wert]
Quelle: [Name], Stand [Datum]
```

Beispiel:
```
📊 Sparerpauschbetrag — Datenänderung
Alt: 1.000 € → Neu: 1.200 €
Quelle: BMF, Stand 22.08.2026
```

## Wortsperre (nie im Alert-Text)

"jetzt", "sofort", "kaufen", "verkaufen", "umschichten", "solltest", "empfehlen wir dir", "handle", "nutze die Chance" — jedes Wort mit Handlungsaufforderung an den einzelnen Empfänger ist verboten, unabhängig vom Kontext.

Auch implizite Signale vermeiden: kein Ausrufezeichen-Hype, keine Dringlichkeits-Framings ("Nur noch heute", "Verpasse nicht"). Ton bleibt sachlich wie eine Nachrichtenagentur-Meldung.

## Tier-Zuordnung

- **Pro Digital:** Wöchentliche Zusammenfassung aller Grün/Gelb-Änderungen der letzten 7 Tage, gebündelt in einer Nachricht.
- **Executive:** Echtzeit-Einzel-Alerts direkt bei Freigabe, filterbar nach Kategorie (z. B. nur Crypto/DeFi).
- **Alert-only-Mini-Abo (optional):** Wie Pro-Kadenz, aber ohne vollen Content-Zugriff.

## Kanal-Hinweis

Telegram Bot API als primärer Kanal (bestehende Infrastruktur aus dem n8n-Stack nutzbar). E-Mail/RSS als Fallback parallel anbieten. WhatsApp Business API und Signal erst bei nachgewiesener Nachfrage prüfen (höherer Integrationsaufwand).

## Vor jedem Versand

1. Guardrails aus kontenlage-wphg-guardrails-Skill anwenden.
2. Nur Grün/Gelb-Status-Daten aus scoring-engine dürfen Alert-Inhalt werden — Rot-Status (unterdrückt/wird geprüft) wird NIE als Alert verschickt.
3. Wortsperre-Check gegen den fertigen Text laufen lassen, bevor er in die Warteschlange geht.
