---
name: kontenlage-scoring-engine
description: Berechnet und aktualisiert Risk/Opportunity/Evidence-Scores für Anlageklassen-Vergleiche auf Kontenlage, in qualitativen Bändern (nicht Dezimalwerten), und wendet die Grün/Gelb/Rot-Publish-Gate-Logik an. Trigger bei jeder neuen Quellenlage zu einer bestehenden Anlageklasse, beim Hinzufügen einer neuen Anlageklasse, oder wenn source-evaluator-Skill neue/widersprüchliche Daten liefert. Muss vor jedem Output kontenlage-wphg-guardrails konsultieren.
---

# Kontenlage Scoring Engine

## Dimensionen (Phase-1-Kernset — bewusst klein, erweiterbar erst nach Audit-Historie)

**Risk-Achse:** Kapitalverlustrisiko · Volatilität · Gegenpartei-/Ausfallrisiko · Liquiditätsrisiko
**Opportunity-Achse:** Renditepotenzial (als Spanne, nicht Punktwert) · Planbarkeit · Diversifikationsbeitrag
**Evidence-Achse:** Quellenzahl · Quellentyp (amtlich/Verband/wissenschaftlich/kommerziell) · Aktualität

## Bewertungsformat — keine Fake-Präzision

Jede Dimension bekommt ein **qualitatives Band**: niedrig / mittel / hoch — niemals einen Dezimalwert (kein "7,3/10"). Jedes Band braucht:
- Eine Kurzbegründung (1 Satz)
- Mindestens eine Quellenangabe mit Datum
- Einen Confidence-Tag (hoch/mittel/niedrig), basierend auf Quellenzahl und -übereinstimmung

Zahlen sind nur dort erlaubt, wo sie direkt aus Marktdaten stammen (historische Volatilität eines Index, aktueller Zinssatz) — nie als erfundene Risiko-Punktzahl.

## Grün/Gelb/Rot-Publish-Gate

**GRÜN — Auto-Publish, kein Gate**
Reine Fakten mit einer amtlichen/institutionellen Quelle (Zinssatz, Freibetrag, historischer Kurswert). Direkt live, Zeitstempel + Quelle automatisch mitpublizieren.

**GELB — Auto-Publish mit Log**
Score-Änderung innerhalb der bisherigen Bandbreite (kein Sprung von "niedrig" auf "hoch"), hohe Konfidenz, ≥2 unabhängige Quellen stimmen überein. Automatisch live, aber in ein Änderungsprotokoll geschrieben. Igor kann jederzeit eine Stichprobe (z. B. wöchentlich 10 % der Gelb-Änderungen) einsehen — das ist Audit, keine Freigabe-Voraussetzung.

**ROT — Fall A: Bestehender Datenpunkt, widersprüchliche Quellen oder niedrige Konfidenz**
NICHT veröffentlichen. Alten Stand beibehalten, Badge "wird geprüft" mit Datum setzen. Vollautomatisch, keine Eskalation. Erneuter Versuch bei nächstem Research-Zyklus.

**ROT — Fall B: Neue Anlageklasse, noch nie bewertet**
NICHT veröffentlichen, bis ein Mindest-Quorum erreicht ist: ≥3 unabhängige Quellen, davon mindestens 1 Tier-1-Quelle (amtlich/institutionell). Vollautomatisch, keine Eskalation. Solange Quorum nicht erreicht: Anlageklasse erscheint nicht im Vergleichssystem.

**ROT — Fall C: Methodik-Änderung**
Neue Dimension, geänderte Bandgrenze, geänderte Quellen-Gewichtung, neue Score-Formel. **Einzige Eskalationsstufe an Igor.** Begründung: Das ist eine Produkt-/Governance-Entscheidung (wie bewerten wir grundsätzlich alles), keine fachliche Einzelfrage — Igor muss dafür kein Domain-Experte sein, sondern trifft eine Entscheidung über das Produkt selbst.

## Quellen-Gewichtung (für Confidence-Berechnung)

| Quelle | Gewicht |
|---|---|
| BaFin, Bundesbank, EZB, BMF, ESMA | Tier 1 |
| Verbraucherzentrale, wissenschaftliche Publikation | Tier 2 |
| Etablierter Datenanbieter (z. B. Morningstar-Daten) | Tier 2 |
| Anbieter-eigene Quelle | Tier 3 |
| Blog, Forum, unverifizierte Social-Media-Quelle | Nicht verwertbar für Score, höchstens als Kontext-Hinweis |

## Output-Format (Beispielstruktur)

```
{
  "anlageklasse": "Geldmarktfonds",
  "dimension": "Liquiditätsrisiko",
  "band": "mittel",
  "begruendung": "Tägliche Liquidität, aber Stressphasen können Bewertung/Verfügbarkeit beeinträchtigen",
  "quellen": [{"name": "EZB", "datum": "2026-08-15", "tier": 1}],
  "confidence": "hoch",
  "status": "gelb",
  "letzte_aenderung": "2026-08-22"
}
```

## Vor jedem Publish

Guardrails aus kontenlage-wphg-guardrails-Skill anwenden (Kategorie-Ebene, Sprache, Selbstprüf-Checkliste), dann erst nach Status.
